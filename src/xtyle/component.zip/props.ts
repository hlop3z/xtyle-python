type Props = {
  class?: string | string[] | object;
  style?: string | string[] | object;
  children?: any;
  title?: string;
};

export default Props;
