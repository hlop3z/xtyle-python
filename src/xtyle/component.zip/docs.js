/**
 * This is a Component.
 *
 * @param {any} [class] - HTML `class`
 * @param {any} [style] - HTML `style`
 * @param {any} [children] - Element's <children />
 * @return {Object} HyperScript `Component`
 *
 * @example
 *
 * <CustomComponent name="my-component"></CustomComponent>
 */
