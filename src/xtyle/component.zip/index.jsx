export default function Component(props) {
  const className = $NAME; // Component Name
  return (
    <div x-html {...props} class={[className, props.class]}>
      Hello World
    </div>
  );
}
