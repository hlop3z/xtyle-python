export default function Component(props) {
  const className = "my-component-css";
  return (
    <div x-html {...props} class={[className, props.class]}>
      Hello World
    </div>
  );
}
